package menu;

public class Menu {

	public static void main(String[] args) {
		
	}

}
